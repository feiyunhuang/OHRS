package exception;



import java.io.Serializable;

public class CheckInException extends Exception  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7458119462796812717L;
	/**
	 * 
	 */
	private int id=0;
	public final static int WRONGPASSWORD=1;
	public final static int  IDNOTEXIT=2;
	public final static int  MORELOGIN=3;
	public CheckInException(int id)
	{
		this.id=id;
	}
	public int getId()
	{
		return id;
	}
	@Override
	public void printStackTrace()
	{
		switch(id)
		{
		case WRONGPASSWORD:
			System.out.println("密码错误");
			break;
		case IDNOTEXIT:
			System.out.println("账号不存在");
			break;
		case MORELOGIN:
			System.out.println("被迫下线");
			break;
		default:
			System.out.println("不明错误");
				
		}
	}

}
