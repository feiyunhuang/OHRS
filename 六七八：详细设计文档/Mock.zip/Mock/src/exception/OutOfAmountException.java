package exception;



import java.io.Serializable;

public 	class OutOfAmountException extends Exception implements Serializable
{


	/**
	 * 
	 */
	private static final long serialVersionUID = -6754642021842147808L;

	public void  printStackTrace()
	{
		System.out.println("超过三个满减策略");
	}
}