package remote;


import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

import javax.net.ssl.SSLEngineResult.Status;

import exception.CheckInException;
import infoClass.Appraisa;
import infoClass.CustomerInformation;
import infoClass.GrogshopInformation;
import infoClass.IndentInformation;
import infoClass.SalePromotionInformation;


public interface CustomerRemote extends Remote {
	
	//用户账号， 密码，类型 返回一个授权码 String的accredit
	public String Login(int id,String password)throws RemoteException ,CheckInException;
	//注册
	public int createNewCustomer(CustomerInformation cusInfor)throws RemoteException,CheckInException;
	//查看信息
	public CustomerInformation checkInformation(String accredit)throws RemoteException,CheckInException;
	//修改密码
	public void modifyPassword(String accredit,String password)throws RemoteException,CheckInException;
	//修改信息
	public boolean modifyInformation(String accredit,CustomerInformation cuInfor)throws RemoteException,CheckInException;
	//获得所有订单
	public IndentInformation[] getIndent(String accredit,int status)throws RemoteException,CheckInException;
	//查看酒店促销策略
	public SalePromotionInformation getSalePromotion(String accredit,int grogshopId)throws RemoteException,CheckInException;
	//通过关键字搜索酒店
	public ArrayList<GrogshopInformation> searchGrogshopByKeyword(String accredit,String keyword,String order,boolean object)throws RemoteException,CheckInException; 
	//通过商圈搜索酒店
	public ArrayList<GrogshopInformation>searchGrogshop(String accredit,String businessArea)throws RemoteException;
	//查看酒店评价 返回评价对象 数组
	public ArrayList<Appraisa> checkAppraisal(String accredit,int grogshopId)throws RemoteException,CheckInException;
	//计算某个订单的价格并返回//indentInformation 为没有打折的价格
	public double caculateCost(String accredit,IndentInformation indentInfor)throws RemoteException,CheckInException;
	//下订单 并返回订单号
	public int createIndent(String accredit,IndentInformation indentInfor)throws RemoteException,CheckInException;
	//评价酒店
	public boolean appraiseGrogshop(String accredit,Appraisa app)throws RemoteException,CheckInException;
	//查看信用记录
	public String checkCreditLog(String accredit)throws RemoteException,CheckInException;
	//同步数据
	public Status synchronous(String accredit)throws RemoteException,CheckInException;
	//登出
	public boolean logout(String accredit)throws RemoteException,CheckInException;

}
