package infoClass;


import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
/*
 * create by zenghuan 10 2
 *
 */

import roomControl.Grogshop_house_type;



public class IndentInformation  implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8349311765014936625L;
	public static final int STATUS_EXECUTE=0;//已执行
	public static final int STATUS_NOT_EXECUTE=1;//未执行
	public static final int STATUS_IRREGULAR=2;//异常订单
	public static final int STATUS_REMOVE=3;//撤销订单
	public static final int STATUS_ISRUNNING=4;//正在运行
	public static final int ALL=-1;//只用于读订单时
	public static final SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH");//时间规范 2014-12-12 23 年月日 时。
	
	
	public int indentId;//9位
	public  String customerName;
	public int customerId;//8位
	public String grogshopName;
	public int grogshopId;//5位
	public int status;//1位
	public int cost;//9位
	
	public Grogshop_house_type hauseType;//订房类型
	public int houseAmount=0;//订房数量
	
	private String createDate="";
	private String checkInDate ="";
	private String checkOutDate="";
	private String predictedCheckIndate="";
	
	public IndentInformation() //服务端读取订单时调用
	{

	}
	
	public IndentInformation(String customerName,int customerId,String grogshopName,int grogshopId)//生成订单时调用
	{
		this.customerName=customerName;
		this.customerId=customerId;
		this.grogshopName=grogshopName;
		this.grogshopId=grogshopId;
		this.status=IndentInformation.STATUS_NOT_EXECUTE;
		this.createDate=sdf.format(new Date());
	}
	
	public void setCreateDate(String createDate) throws ParseException
	{
		sdf.parse(createDate);
		this.createDate=createDate;
	}
	public void setCheckInDate(String date) throws ParseException
	{
		sdf.parse(date);
		this.checkInDate=date;
	}
	
	public void setPredictedCheckIndate(String date) throws ParseException
	{
		sdf.parse(date);
		this.predictedCheckIndate=date;
	}
	
	public void setCheckOutDate(String date) throws ParseException
	{
		sdf.parse(date);
		this.checkOutDate=date;
	}
	
	
	public String getCreateDate()
	{
		return createDate;
	}
	
	public String getCheckInDate()
	{
		return checkInDate;
	}
	
	public String getCheckOutDate()
	{
		return checkOutDate;
	}
	
	public String getPredictedCheckIndate()
	{
		return predictedCheckIndate;
	}
	
	public String getSql()
	{
		int id= hauseType.ordinal();
		return indentId+","+customerId+",'"+customerName+"',"+grogshopId+",'"+grogshopName+"',"+status
				+",'"+createDate+"','"+checkInDate+"','"+checkOutDate+"','"+predictedCheckIndate+"',"+cost+","+id+","+this.houseAmount;
	}
	
	/*	
		Calendar c=Calendar.getInstance();
		c.set(2015, 0, 31, 13);2015-1-31 13
		Date d=c.getTime();
	 */

}
