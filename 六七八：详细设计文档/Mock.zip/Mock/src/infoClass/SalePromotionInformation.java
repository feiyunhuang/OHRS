package infoClass;


import java.io.Serializable;

import exception.OutOfAmountException;



/*
 * @author 曾欢
 */
public class SalePromotionInformation  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7179592565948678016L;
	private int vipDiscount0=100;//普通的人折扣，1-100
	private int vipDiscount1=100;//vip的折扣1-100
	private int vipDiscount2=100;//vip2
	private int vipDiscount3=100;//vip3
	private int vipDiscount4=100;//vip4
	private int vipDiscount5=100;//vip5
	public int grogshopId=0;//8位
	/*
	 * 满fullAmount【0】 减fullSubtract[0],fullAmount[2]>fullAmount[1]>fullAmount[0]
	 */
	private int fullAmount[]={Integer.MAX_VALUE,Integer.MAX_VALUE,Integer.MAX_VALUE};
	private int fullSubtract[]={0,0,0};
	public  String descreption="";
	
	public boolean setFullSubtract(int[] amount,int[]subtract) throws OutOfAmountException
	{
		if(amount.length>=4||subtract.length>=4)
			{
				throw new OutOfAmountException();
			}
		int i=0;
		for(i=0;i<amount.length;i++)
		{
				fullAmount[i]=amount[i];
		}
		for(int j=0;j<i;j++)
		{
			try{
				fullSubtract[j]=subtract[j];
			}catch(ArrayIndexOutOfBoundsException e)
			{
				fullAmount[j]=Integer.MAX_VALUE;
			}
		}
		return true;
	}
	
	public void setDiscount(int...di)
	{
		int i=di.length;
		int dis[]=new int[6];
		for(;i<6;i++)
		{
			dis[i]=di[di.length-1];
		}
		vipDiscount0=dis[0];
		vipDiscount1=dis[1];
		vipDiscount2=dis[2];
		vipDiscount3=dis[3];
		vipDiscount4=dis[4];
		vipDiscount5=dis[5];
	}
	
	public double caculateCost(int cost,int vip)
	{
		if(cost>=fullAmount[2])
		{
			return cost-fullSubtract[2];
		}else if(cost>fullAmount[1])
		{
			return cost-fullAmount[1];
		}else if(cost>fullAmount[0])
			return cost-fullSubtract[0];
		switch(vip)
		{
		case 0:
			return cost/100.0*vipDiscount0;
		case 1:
			return cost/100.0*vipDiscount1;
		case 2:
			return cost/100.0*vipDiscount2;
		case 3:
			return cost/100.0*vipDiscount3;
		case 4:
			return cost/100.0*vipDiscount4;
		default:
			return cost/100.0*vipDiscount5;
		
			
		}
	
		
	}

	public String getSql()
	{
		return "set vipDiscount0="+vipDiscount0+",vipDiscount1="+vipDiscount1+",vipDiscount2="+vipDiscount2+",vipDiscount3="+vipDiscount3+", fullAmount1="+fullAmount[0]+",fullAmount2="+fullAmount[1]+",fullAmount3="
				+fullAmount[2]+",fullSubtract1="+fullSubtract[0]+",fullSubtract2="+fullSubtract[1]+",fullSubtract3="
				+fullSubtract[2]+",descreption='"+descreption+"'";
	}
	
	public String getInsertSql()
	{
		return grogshopId+","+vipDiscount0+","+vipDiscount1+","+vipDiscount2+","
		+vipDiscount3+","+vipDiscount4+","+vipDiscount5+","+fullAmount[0]+","
		+fullAmount[1]+","+fullAmount[2]+","+fullSubtract[0]+","+fullSubtract[1]
		+","+fullSubtract[2]+",'"+this.descreption+"'";
	}
	


}
