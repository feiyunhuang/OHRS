package infoClass;



import java.io.Serializable;
import java.util.Date;
/*
 * create by zenghuan 10 2
 * 客户的数据包，
 */
public class CustomerInformation   implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3124275534866956248L;
	public int customerId;//8位
	public String name;//100个字节酒店名字
	public String password;//50个字节工作人员密码
	public boolean sex;//true 为男，false 为女
	public Date birthday;//生日，年月日
	public String phoneNumber;//电话号码
	public int credit;//信用值
	public int getVipRank()
	{
		int cr=credit;
		if(cr>100000)
			return 5;
		if(cr>10000)
			return 4;
		if(cr>5000)
			return 3;
		if(cr>1000)
			return 2;
		if(cr>100)
			return 1;
		return 0;
	}
	public static int caculatorVipRank(int cr)
	{
		
		if(cr>100000)
			return 5;
		if(cr>10000)
			return 4;
		if(cr>5000)
			return 3;
		if(cr>1000)
			return 2;
		if(cr>100)
			return 1;
		return 0;
	}
	
}
