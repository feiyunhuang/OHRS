package infoClass;

import java.io.Serializable;

/*
 * @author 曾欢
 */
public class Appraisa implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8850578114916682787L;
	public String txt;//评价的正文
	public int customerId;//顾客账号8位
	public int grogshopId;//酒店id5位
	public int satisfaction;//评价星级越多越满意
}
