package userText;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Date;

import exception.CheckInException;
import infoClass.CustomerInformation;
import infoClass.IndentInformation;
import infoClass.SalePromotionInformation;
import remote.CustomerRemote;

public class setData {
	String rmi;
	CustomerRemote customerRemote;
	//补充用户信息
	CustomerInformation customerInformation;
	//用户历史订单信息
	IndentInformation[] information;
	public setData(){
		try{
			customerRemote = (CustomerRemote) Naming.lookup("rmi://"+rmi);
		
		}catch(MalformedURLException e){
			System.out.println("存在非法输入");
		}catch(RemoteException e){
			System.out.println("网络错误");
		}catch( NotBoundException e){
			System.out.println("路径配置错误");
		}
		setUserInfo();
		setIDright();
	}
	private void setUserInfo() {
		// TODO Auto-generated method stub
		 customerInformation.customerId = 630268696;
		 customerInformation.name = "高翔";
		 customerInformation.password = "18805156570";
		 customerInformation.sex = true;
		 //birthday
		 customerInformation .phoneNumber = "18805156570";
		 customerInformation .credit = 0;
	}
	private void setIDright() {
		// TODO Auto-generated method stub
		try {
			customerRemote.createNewCustomer(customerInformation);
			customerRemote.Login(630268696, "18805156570");
			
		} catch (RemoteException | CheckInException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("初始化信息错误");
		}
		
	}
	public void getIndent() throws RemoteException, CheckInException{
		information = customerRemote.getIndent("630268696", 0);
	}
	public SalePromotionInformation getMoney() throws RemoteException, CheckInException{
		return customerRemote.getSalePromotion("630268696", 0);
	}
	
}
