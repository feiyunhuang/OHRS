package userText;

import static org.junit.Assert.*;

import java.rmi.RemoteException;

import org.junit.Test;

import exception.CheckInException;
import infoClass.Appraisa;
import infoClass.CustomerInformation;
import infoClass.IndentInformation;
import infoClass.SalePromotionInformation;

public class textFace {
	IndentInformation[] info;
	setData setData = new setData();
	CustomerInformation customInfo;
	Appraisa app;
	SalePromotionInformation hotalInfo;
	@Test
	public void testcheckInfo() throws RemoteException, CheckInException {
		assertEquals(setData.customerInformation, setData.customerRemote.checkInformation("630268696"));
	}
	@Test
	public void modifyPasswordTest() throws RemoteException, CheckInException{
		setData.customerRemote.modifyPassword("630268696", "18805156570qq");
		assertEquals("18805156570qq",setData.customerInformation.password );
	}
	@Test
	public void modifyInformation() throws RemoteException, CheckInException{
		setData.customerRemote.modifyInformation("630268696", customInfo);
		assertEquals(customInfo, setData.customerInformation);
	}
	@Test
	public void getSalePromotion() throws RemoteException, CheckInException{
		assertEquals(setData.customerRemote.getIndent("3476289", 0), hotalInfo);
	}
	@Test
	public void getIndentTest() throws RemoteException, CheckInException{
		setData.getIndent();
		assertEquals(info, setData.information);
	}
	@Test
	public void appraiseGrogshop() throws RemoteException, CheckInException{
		assertEquals(false, setData.customerRemote.appraiseGrogshop("00", app));
	}
}
