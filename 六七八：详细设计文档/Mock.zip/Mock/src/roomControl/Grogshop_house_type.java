package roomControl;



import java.io.Serializable;

/*
 * @author 曾欢  
 * @date 10 9
 * 酒店房间类型，标准单人房，标准双人房，豪华单人房，豪华双人房，家庭房
 */
public enum Grogshop_house_type  implements Serializable
{STANDARSINGAL,STANDARDOUBLE,LUXURYSINGAL,LUXURYDOUBLE,FAMILY;
	public static Grogshop_house_type toEnum(int id)
	{
		switch(id)
		{
		case 0:
			return STANDARSINGAL;
		case 1:
			return STANDARDOUBLE;
		case 2:
			return LUXURYSINGAL;
		case 3:
			return LUXURYDOUBLE;
		case 4:
			return FAMILY;
			
		}
		return null;
	}

};

